package com.example.rest_h2_jpa_lombok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestH2JpaLombokApplicationTests {

	@Test
	void contextLoads() {
	}

}
