package com.example.rest_h2_jpa_lombok;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestH2JpaLombokApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestH2JpaLombokApplication.class, args);
	}

}
