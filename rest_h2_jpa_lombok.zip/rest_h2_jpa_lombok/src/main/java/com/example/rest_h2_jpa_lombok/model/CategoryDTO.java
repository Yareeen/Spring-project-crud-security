package com.example.rest_h2_jpa_lombok.model;


import lombok.Data;

@Data
public class CategoryDTO {
    private Long id;
    private String name;


}